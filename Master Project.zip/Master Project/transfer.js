function validate(){
let accno=document.myform.accno.value;
let name=document.myform.name.value;
let ifsc=document.myform.ifsc.value;
let amt=document.myform.amt.value;

if(accno==''){
    alert("Account Number cannot be Empty");
    return false;
}
if(name==''){
    alert("Name Cannot be Empty");
    return false;
}
if(ifsc==''){
    alert("Ifsc Cannot be Empty");
    return false;
}

if(amt==''){
    alert("Amount Cannot be Empty");
    return false;
}
else{
    return true;
}

}


