function login(){
let userid=document.myform.userid.value;
let pass=document.myform.pwd.value;

if(userid==''){
    alert("User Id cannot be Empty");
    return false;
}
if(pass==''){
    alert("Password Cannot be Empty");
    return false;
}
else{
    return true;
}

}


