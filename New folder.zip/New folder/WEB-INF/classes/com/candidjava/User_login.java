package com.candidjava;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDataServlet
 */
public class User_login extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		// validate given input
		if(userid.isEmpty()||password.isEmpty())
		{
			RequestDispatcher rd = request.getRequestDispatcher("user_login.jsp");
			out.println("<font color=red>Please fill all the fields</font>");
			rd.include(request, response);
		}
		else
		{
			// inserting data into mysql database
			// create a test database and student table before running this
			// to create table -  create table student(name varchar(100), userName varchar(100), pass varchar(100), addr varchar(100), age int, qual varchar(100), percent varchar(100), year varchar(100));
			try {
				Class.forName("com.mysql.jdbc.Driver");
			// loads mysql driver
			
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/banking", "root", "root"); // create new connection with test database
			
			String query="select custid,pass from cust_register where custid=? and pass=?";
			
			PreparedStatement ps=con.prepareStatement(query);  // generates sql query
			
			ps.setString(1, userid);
			ps.setString(2, password);
			
			ResultSet rs=ps.executeQuery();// execute it on test database
			
			while(rs.next()) {
				System.out.println("Login successfully");
				out.write("<h1>Login Successfull</h1>");
				return;
			}
			System.out.println("Error");
			out.write("<h1>Error</h1>");
			return;
			
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
